/**
 * Package for all frames.
 *
 * @author Roger Williams
 */
package edu.gsu.csc1302.GUI.frame;
