/**
 * the package information class.
 * @author Mahetem Moges
 */
package edu.gsu.csc1302.GUI;
