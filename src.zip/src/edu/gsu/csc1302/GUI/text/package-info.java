/**
 * Package for all the GUI heading related classes, h1, h2, h3.
 *
 * @author Roger Williams
 */
package edu.gsu.csc1302.GUI.text;
