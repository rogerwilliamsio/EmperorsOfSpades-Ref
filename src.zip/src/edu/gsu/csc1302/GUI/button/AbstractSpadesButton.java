package edu.gsu.csc1302.GUI.button;

import edu.gsu.csc1302.GUI.SpadesComponent;

/**
 * An abstract spades button.
 *
 * @author Roger Williams
 */
@SuppressWarnings("serial")
public abstract class AbstractSpadesButton extends SpadesComponent {
}
