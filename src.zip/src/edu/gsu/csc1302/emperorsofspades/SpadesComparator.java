package edu.gsu.csc1302.emperorsofspades;

import edu.gsu.csc1302.emperorsofspades.instructorsolutions.Card.Suit;
import edu.gsu.csc1302.emperorsofspades.instructorsolutions.InstrSpadesComparator;

public class SpadesComparator extends InstrSpadesComparator {

	public SpadesComparator(Suit leadSuit) {
		super(leadSuit);
	}

}
