//package edu.gsu.csc1302.emperorsofspades;
///**
// * @author Mahetem Moges
// */
//public class Round {
//	private integer round;
//	Round(){
//		round = 1;
//	}
//	public void playHand() {
//
//	}
//}
