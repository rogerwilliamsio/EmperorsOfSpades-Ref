/**
 * Classes that  are from the instructor's past solutions.
 * Deck class is used with our CardDeck class.
 * @author Roger Williams
 */
package edu.gsu.csc1302.emperorsofspades.instructorsolutions;
