//import edu.gsu.csc1302.emperorsofspades.player.ai.AIPlayer;
//import edu.gsu.csc1302.emperorsofspades.player.ai.AggressivePlayer;
//import org.junit.jupiter.api.Test;
//
///**
// * Tests the functionality of the AI Players.
// *
// * @author Roger Williams
// */
//public class AIPlayerTest {
//
//    private AIPlayer agressiveAI = new AggressivePlayer("Roger");
//
//}
