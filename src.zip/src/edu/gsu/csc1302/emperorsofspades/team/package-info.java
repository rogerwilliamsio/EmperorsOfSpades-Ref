/**
 * Classes related to the teams in the game.
 *
 * @author Roger Williams
 */
package edu.gsu.csc1302.emperorsofspades.team;
