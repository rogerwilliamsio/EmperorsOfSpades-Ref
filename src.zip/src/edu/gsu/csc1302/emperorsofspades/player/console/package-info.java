/**
 * Classes that a related to the console game player.
 * @author Roger Williams
 */
package edu.gsu.csc1302.emperorsofspades.player.console;
